﻿namespace MemberMaint
{
    partial class SkillSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSkills = new System.Windows.Forms.Panel();
            this.btnStartSkill = new System.Windows.Forms.Button();
            this.checkBox29Geek = new System.Windows.Forms.CheckBox();
            this.checkBox28AudioVideo = new System.Windows.Forms.CheckBox();
            this.checkBox27Youth = new System.Windows.Forms.CheckBox();
            this.checkBox26TeenMin = new System.Windows.Forms.CheckBox();
            this.checkBox25Organ = new System.Windows.Forms.CheckBox();
            this.checkBox24airOwner = new System.Windows.Forms.CheckBox();
            this.checkBox23Airpilot = new System.Windows.Forms.CheckBox();
            this.checkBox22House = new System.Windows.Forms.CheckBox();
            this.checkBox21Lock = new System.Windows.Forms.CheckBox();
            this.checkBox20HeatAir = new System.Windows.Forms.CheckBox();
            this.checkBox19Plum = new System.Windows.Forms.CheckBox();
            this.checkBox18Carpenter = new System.Windows.Forms.CheckBox();
            this.checkBox17Solo = new System.Windows.Forms.CheckBox();
            this.checkBox16Pianio = new System.Windows.Forms.CheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.checkBox15English = new System.Windows.Forms.CheckBox();
            this.checkBox14German = new System.Windows.Forms.CheckBox();
            this.checkBox13Spanish = new System.Windows.Forms.CheckBox();
            this.checkBox11Math = new System.Windows.Forms.CheckBox();
            this.checkBox10Elect = new System.Windows.Forms.CheckBox();
            this.checkBox9lawn = new System.Windows.Forms.CheckBox();
            this.checkBox8foodsvc = new System.Windows.Forms.CheckBox();
            this.checkBox7driver = new System.Windows.Forms.CheckBox();
            this.checkBox6nurse = new System.Windows.Forms.CheckBox();
            this.checkBox5care = new System.Windows.Forms.CheckBox();
            this.checkBox4PublSpeak = new System.Windows.Forms.CheckBox();
            this.checkBox3AutoMech = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.chkCooking = new System.Windows.Forms.CheckBox();
            this.chkTreeCutting = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbtnAnd = new System.Windows.Forms.RadioButton();
            this.rbtnOR = new System.Windows.Forms.RadioButton();
            this.pnlSkills.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSkills
            // 
            this.pnlSkills.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSkills.Controls.Add(this.btnStartSkill);
            this.pnlSkills.Controls.Add(this.checkBox29Geek);
            this.pnlSkills.Controls.Add(this.checkBox28AudioVideo);
            this.pnlSkills.Controls.Add(this.checkBox27Youth);
            this.pnlSkills.Controls.Add(this.checkBox26TeenMin);
            this.pnlSkills.Controls.Add(this.checkBox25Organ);
            this.pnlSkills.Controls.Add(this.checkBox24airOwner);
            this.pnlSkills.Controls.Add(this.checkBox23Airpilot);
            this.pnlSkills.Controls.Add(this.checkBox22House);
            this.pnlSkills.Controls.Add(this.checkBox21Lock);
            this.pnlSkills.Controls.Add(this.checkBox20HeatAir);
            this.pnlSkills.Controls.Add(this.checkBox19Plum);
            this.pnlSkills.Controls.Add(this.checkBox18Carpenter);
            this.pnlSkills.Controls.Add(this.checkBox17Solo);
            this.pnlSkills.Controls.Add(this.checkBox16Pianio);
            this.pnlSkills.Controls.Add(this.label28);
            this.pnlSkills.Controls.Add(this.checkBox15English);
            this.pnlSkills.Controls.Add(this.checkBox14German);
            this.pnlSkills.Controls.Add(this.checkBox13Spanish);
            this.pnlSkills.Controls.Add(this.checkBox11Math);
            this.pnlSkills.Controls.Add(this.checkBox10Elect);
            this.pnlSkills.Controls.Add(this.checkBox9lawn);
            this.pnlSkills.Controls.Add(this.checkBox8foodsvc);
            this.pnlSkills.Controls.Add(this.checkBox7driver);
            this.pnlSkills.Controls.Add(this.checkBox6nurse);
            this.pnlSkills.Controls.Add(this.checkBox5care);
            this.pnlSkills.Controls.Add(this.checkBox4PublSpeak);
            this.pnlSkills.Controls.Add(this.checkBox3AutoMech);
            this.pnlSkills.Controls.Add(this.label27);
            this.pnlSkills.Controls.Add(this.chkCooking);
            this.pnlSkills.Controls.Add(this.chkTreeCutting);
            this.pnlSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlSkills.ForeColor = System.Drawing.SystemColors.MenuText;
            this.pnlSkills.Location = new System.Drawing.Point(247, 44);
            this.pnlSkills.Name = "pnlSkills";
            this.pnlSkills.Size = new System.Drawing.Size(307, 363);
            this.pnlSkills.TabIndex = 67;
            this.pnlSkills.Visible = false;
            // 
            // btnStartSkill
            // 
            this.btnStartSkill.Location = new System.Drawing.Point(103, 310);
            this.btnStartSkill.Name = "btnStartSkill";
            this.btnStartSkill.Size = new System.Drawing.Size(136, 23);
            this.btnStartSkill.TabIndex = 83;
            this.btnStartSkill.Text = "begin search";
            this.btnStartSkill.UseVisualStyleBackColor = true;
            this.btnStartSkill.Click += new System.EventHandler(this.btnStartSkill_Click);
            // 
            // checkBox29Geek
            // 
            this.checkBox29Geek.AutoSize = true;
            this.checkBox29Geek.Location = new System.Drawing.Point(138, 287);
            this.checkBox29Geek.Name = "checkBox29Geek";
            this.checkBox29Geek.Size = new System.Drawing.Size(110, 17);
            this.checkBox29Geek.TabIndex = 82;
            this.checkBox29Geek.Text = "Computer Nerd";
            this.checkBox29Geek.UseVisualStyleBackColor = true;
            // 
            // checkBox28AudioVideo
            // 
            this.checkBox28AudioVideo.AutoSize = true;
            this.checkBox28AudioVideo.Location = new System.Drawing.Point(138, 267);
            this.checkBox28AudioVideo.Name = "checkBox28AudioVideo";
            this.checkBox28AudioVideo.Size = new System.Drawing.Size(96, 17);
            this.checkBox28AudioVideo.TabIndex = 81;
            this.checkBox28AudioVideo.Text = "Audio/Video";
            this.checkBox28AudioVideo.UseVisualStyleBackColor = true;
            // 
            // checkBox27Youth
            // 
            this.checkBox27Youth.AutoSize = true;
            this.checkBox27Youth.Location = new System.Drawing.Point(138, 247);
            this.checkBox27Youth.Name = "checkBox27Youth";
            this.checkBox27Youth.Size = new System.Drawing.Size(116, 17);
            this.checkBox27Youth.TabIndex = 80;
            this.checkBox27Youth.Text = "Youth Ministries";
            this.checkBox27Youth.UseVisualStyleBackColor = true;
            // 
            // checkBox26TeenMin
            // 
            this.checkBox26TeenMin.AutoSize = true;
            this.checkBox26TeenMin.Location = new System.Drawing.Point(138, 227);
            this.checkBox26TeenMin.Name = "checkBox26TeenMin";
            this.checkBox26TeenMin.Size = new System.Drawing.Size(112, 17);
            this.checkBox26TeenMin.TabIndex = 79;
            this.checkBox26TeenMin.Text = "Teen Ministries";
            this.checkBox26TeenMin.UseVisualStyleBackColor = true;
            // 
            // checkBox25Organ
            // 
            this.checkBox25Organ.AutoSize = true;
            this.checkBox25Organ.Location = new System.Drawing.Point(138, 207);
            this.checkBox25Organ.Name = "checkBox25Organ";
            this.checkBox25Organ.Size = new System.Drawing.Size(73, 17);
            this.checkBox25Organ.TabIndex = 78;
            this.checkBox25Organ.Text = "Organist";
            this.checkBox25Organ.UseVisualStyleBackColor = true;
            // 
            // checkBox24airOwner
            // 
            this.checkBox24airOwner.AutoSize = true;
            this.checkBox24airOwner.Location = new System.Drawing.Point(138, 187);
            this.checkBox24airOwner.Name = "checkBox24airOwner";
            this.checkBox24airOwner.Size = new System.Drawing.Size(107, 17);
            this.checkBox24airOwner.TabIndex = 77;
            this.checkBox24airOwner.Text = "Aircraft Owner";
            this.checkBox24airOwner.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox24airOwner.UseVisualStyleBackColor = true;
            // 
            // checkBox23Airpilot
            // 
            this.checkBox23Airpilot.AutoSize = true;
            this.checkBox23Airpilot.Location = new System.Drawing.Point(138, 167);
            this.checkBox23Airpilot.Name = "checkBox23Airpilot";
            this.checkBox23Airpilot.Size = new System.Drawing.Size(96, 17);
            this.checkBox23Airpilot.TabIndex = 76;
            this.checkBox23Airpilot.Text = "Aircraft Pilot";
            this.checkBox23Airpilot.UseVisualStyleBackColor = true;
            // 
            // checkBox22House
            // 
            this.checkBox22House.AutoSize = true;
            this.checkBox22House.Location = new System.Drawing.Point(138, 147);
            this.checkBox22House.Name = "checkBox22House";
            this.checkBox22House.Size = new System.Drawing.Size(115, 17);
            this.checkBox22House.TabIndex = 75;
            this.checkBox22House.Text = "House Cleaning";
            this.checkBox22House.UseVisualStyleBackColor = true;
            // 
            // checkBox21Lock
            // 
            this.checkBox21Lock.AutoSize = true;
            this.checkBox21Lock.Location = new System.Drawing.Point(138, 127);
            this.checkBox21Lock.Name = "checkBox21Lock";
            this.checkBox21Lock.Size = new System.Drawing.Size(100, 17);
            this.checkBox21Lock.TabIndex = 74;
            this.checkBox21Lock.Text = "Locksmithing";
            this.checkBox21Lock.UseVisualStyleBackColor = true;
            // 
            // checkBox20HeatAir
            // 
            this.checkBox20HeatAir.AutoSize = true;
            this.checkBox20HeatAir.Location = new System.Drawing.Point(138, 107);
            this.checkBox20HeatAir.Name = "checkBox20HeatAir";
            this.checkBox20HeatAir.Size = new System.Drawing.Size(82, 17);
            this.checkBox20HeatAir.TabIndex = 73;
            this.checkBox20HeatAir.Text = "Heat / Air";
            this.checkBox20HeatAir.UseVisualStyleBackColor = true;
            // 
            // checkBox19Plum
            // 
            this.checkBox19Plum.AutoSize = true;
            this.checkBox19Plum.Location = new System.Drawing.Point(138, 87);
            this.checkBox19Plum.Name = "checkBox19Plum";
            this.checkBox19Plum.Size = new System.Drawing.Size(77, 17);
            this.checkBox19Plum.TabIndex = 72;
            this.checkBox19Plum.Text = "Plumbing";
            this.checkBox19Plum.UseVisualStyleBackColor = true;
            // 
            // checkBox18Carpenter
            // 
            this.checkBox18Carpenter.AutoSize = true;
            this.checkBox18Carpenter.Location = new System.Drawing.Point(138, 67);
            this.checkBox18Carpenter.Name = "checkBox18Carpenter";
            this.checkBox18Carpenter.Size = new System.Drawing.Size(81, 17);
            this.checkBox18Carpenter.TabIndex = 71;
            this.checkBox18Carpenter.Text = "Carpenter";
            this.checkBox18Carpenter.UseVisualStyleBackColor = true;
            // 
            // checkBox17Solo
            // 
            this.checkBox17Solo.AutoSize = true;
            this.checkBox17Solo.Location = new System.Drawing.Point(138, 47);
            this.checkBox17Solo.Name = "checkBox17Solo";
            this.checkBox17Solo.Size = new System.Drawing.Size(64, 17);
            this.checkBox17Solo.TabIndex = 70;
            this.checkBox17Solo.Text = "Soloist";
            this.checkBox17Solo.UseVisualStyleBackColor = true;
            // 
            // checkBox16Pianio
            // 
            this.checkBox16Pianio.AutoSize = true;
            this.checkBox16Pianio.Location = new System.Drawing.Point(138, 27);
            this.checkBox16Pianio.Name = "checkBox16Pianio";
            this.checkBox16Pianio.Size = new System.Drawing.Size(64, 17);
            this.checkBox16Pianio.TabIndex = 69;
            this.checkBox16Pianio.Text = "Pianist";
            this.checkBox16Pianio.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(40, 336);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(212, 17);
            this.label28.TabIndex = 68;
            this.label28.Text = "Please Check All That Apply";
            // 
            // checkBox15English
            // 
            this.checkBox15English.AutoSize = true;
            this.checkBox15English.Location = new System.Drawing.Point(5, 287);
            this.checkBox15English.Name = "checkBox15English";
            this.checkBox15English.Size = new System.Drawing.Size(118, 17);
            this.checkBox15English.TabIndex = 67;
            this.checkBox15English.Text = "English Tutoring";
            this.checkBox15English.UseVisualStyleBackColor = true;
            // 
            // checkBox14German
            // 
            this.checkBox14German.AutoSize = true;
            this.checkBox14German.Location = new System.Drawing.Point(5, 267);
            this.checkBox14German.Name = "checkBox14German";
            this.checkBox14German.Size = new System.Drawing.Size(136, 17);
            this.checkBox14German.TabIndex = 66;
            this.checkBox14German.Text = "German Translation";
            this.checkBox14German.UseVisualStyleBackColor = true;
            // 
            // checkBox13Spanish
            // 
            this.checkBox13Spanish.AutoSize = true;
            this.checkBox13Spanish.Location = new System.Drawing.Point(5, 247);
            this.checkBox13Spanish.Name = "checkBox13Spanish";
            this.checkBox13Spanish.Size = new System.Drawing.Size(138, 17);
            this.checkBox13Spanish.TabIndex = 65;
            this.checkBox13Spanish.Text = "Spanish Translation";
            this.checkBox13Spanish.UseVisualStyleBackColor = true;
            // 
            // checkBox11Math
            // 
            this.checkBox11Math.AutoSize = true;
            this.checkBox11Math.Location = new System.Drawing.Point(5, 227);
            this.checkBox11Math.Name = "checkBox11Math";
            this.checkBox11Math.Size = new System.Drawing.Size(105, 17);
            this.checkBox11Math.TabIndex = 63;
            this.checkBox11Math.Text = "Math Tutoring";
            this.checkBox11Math.UseVisualStyleBackColor = true;
            // 
            // checkBox10Elect
            // 
            this.checkBox10Elect.AutoSize = true;
            this.checkBox10Elect.Location = new System.Drawing.Point(5, 207);
            this.checkBox10Elect.Name = "checkBox10Elect";
            this.checkBox10Elect.Size = new System.Drawing.Size(119, 17);
            this.checkBox10Elect.TabIndex = 62;
            this.checkBox10Elect.Text = "Electrical Wiring";
            this.checkBox10Elect.UseVisualStyleBackColor = true;
            // 
            // checkBox9lawn
            // 
            this.checkBox9lawn.AutoSize = true;
            this.checkBox9lawn.Location = new System.Drawing.Point(5, 187);
            this.checkBox9lawn.Name = "checkBox9lawn";
            this.checkBox9lawn.Size = new System.Drawing.Size(86, 17);
            this.checkBox9lawn.TabIndex = 61;
            this.checkBox9lawn.Text = "Lawn Care";
            this.checkBox9lawn.UseVisualStyleBackColor = true;
            // 
            // checkBox8foodsvc
            // 
            this.checkBox8foodsvc.AutoSize = true;
            this.checkBox8foodsvc.Location = new System.Drawing.Point(5, 167);
            this.checkBox8foodsvc.Name = "checkBox8foodsvc";
            this.checkBox8foodsvc.Size = new System.Drawing.Size(101, 17);
            this.checkBox8foodsvc.TabIndex = 60;
            this.checkBox8foodsvc.Text = "Food Service";
            this.checkBox8foodsvc.UseVisualStyleBackColor = true;
            // 
            // checkBox7driver
            // 
            this.checkBox7driver.AutoSize = true;
            this.checkBox7driver.Location = new System.Drawing.Point(5, 147);
            this.checkBox7driver.Name = "checkBox7driver";
            this.checkBox7driver.Size = new System.Drawing.Size(60, 17);
            this.checkBox7driver.TabIndex = 59;
            this.checkBox7driver.Text = "Driver";
            this.checkBox7driver.UseVisualStyleBackColor = true;
            // 
            // checkBox6nurse
            // 
            this.checkBox6nurse.AutoSize = true;
            this.checkBox6nurse.Location = new System.Drawing.Point(5, 127);
            this.checkBox6nurse.Name = "checkBox6nurse";
            this.checkBox6nurse.Size = new System.Drawing.Size(73, 17);
            this.checkBox6nurse.TabIndex = 58;
            this.checkBox6nurse.Text = "Nursing ";
            this.checkBox6nurse.UseVisualStyleBackColor = true;
            // 
            // checkBox5care
            // 
            this.checkBox5care.AutoSize = true;
            this.checkBox5care.Location = new System.Drawing.Point(5, 107);
            this.checkBox5care.Name = "checkBox5care";
            this.checkBox5care.Size = new System.Drawing.Size(119, 17);
            this.checkBox5care.TabIndex = 57;
            this.checkBox5care.Text = "Child/Adult Care";
            this.checkBox5care.UseVisualStyleBackColor = true;
            // 
            // checkBox4PublSpeak
            // 
            this.checkBox4PublSpeak.AutoSize = true;
            this.checkBox4PublSpeak.Location = new System.Drawing.Point(5, 87);
            this.checkBox4PublSpeak.Name = "checkBox4PublSpeak";
            this.checkBox4PublSpeak.Size = new System.Drawing.Size(118, 17);
            this.checkBox4PublSpeak.TabIndex = 56;
            this.checkBox4PublSpeak.Text = "Public Speaking";
            this.checkBox4PublSpeak.UseVisualStyleBackColor = true;
            // 
            // checkBox3AutoMech
            // 
            this.checkBox3AutoMech.AutoSize = true;
            this.checkBox3AutoMech.Location = new System.Drawing.Point(5, 67);
            this.checkBox3AutoMech.Name = "checkBox3AutoMech";
            this.checkBox3AutoMech.Size = new System.Drawing.Size(111, 17);
            this.checkBox3AutoMech.TabIndex = 55;
            this.checkBox3AutoMech.Text = "Auto Mechanic";
            this.checkBox3AutoMech.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(43, 5);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(112, 15);
            this.label27.TabIndex = 54;
            this.label27.Text = "Shareable Skills";
            // 
            // chkCooking
            // 
            this.chkCooking.AutoSize = true;
            this.chkCooking.Location = new System.Drawing.Point(5, 27);
            this.chkCooking.Name = "chkCooking";
            this.chkCooking.Size = new System.Drawing.Size(72, 17);
            this.chkCooking.TabIndex = 52;
            this.chkCooking.Text = "Cooking";
            this.chkCooking.UseVisualStyleBackColor = true;
            // 
            // chkTreeCutting
            // 
            this.chkTreeCutting.AutoSize = true;
            this.chkTreeCutting.Location = new System.Drawing.Point(5, 47);
            this.chkTreeCutting.Name = "chkTreeCutting";
            this.chkTreeCutting.Size = new System.Drawing.Size(96, 17);
            this.chkTreeCutting.TabIndex = 53;
            this.chkTreeCutting.Text = "Tree Cutting";
            this.chkTreeCutting.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbtnAnd);
            this.panel1.Controls.Add(this.rbtnOR);
            this.panel1.Location = new System.Drawing.Point(45, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(131, 100);
            this.panel1.TabIndex = 68;
            // 
            // rbtnAnd
            // 
            this.rbtnAnd.AutoSize = true;
            this.rbtnAnd.Location = new System.Drawing.Point(13, 61);
            this.rbtnAnd.Name = "rbtnAnd";
            this.rbtnAnd.Size = new System.Drawing.Size(68, 17);
            this.rbtnAnd.TabIndex = 1;
            this.rbtnAnd.TabStop = true;
            this.rbtnAnd.Text = "and logic";
            this.rbtnAnd.UseVisualStyleBackColor = true;
            // 
            // rbtnOR
            // 
            this.rbtnOR.AutoSize = true;
            this.rbtnOR.Location = new System.Drawing.Point(13, 19);
            this.rbtnOR.Name = "rbtnOR";
            this.rbtnOR.Size = new System.Drawing.Size(59, 17);
            this.rbtnOR.TabIndex = 0;
            this.rbtnOR.TabStop = true;
            this.rbtnOR.Text = "or logic";
            this.rbtnOR.UseVisualStyleBackColor = true;
            // 
            // SkillSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlSkills);
            this.Name = "SkillSearch";
            this.Text = "SkillSearch";
            this.pnlSkills.ResumeLayout(false);
            this.pnlSkills.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlSkills;
        private System.Windows.Forms.Button btnStartSkill;
        private System.Windows.Forms.CheckBox checkBox29Geek;
        private System.Windows.Forms.CheckBox checkBox28AudioVideo;
        private System.Windows.Forms.CheckBox checkBox27Youth;
        private System.Windows.Forms.CheckBox checkBox26TeenMin;
        private System.Windows.Forms.CheckBox checkBox25Organ;
        private System.Windows.Forms.CheckBox checkBox24airOwner;
        private System.Windows.Forms.CheckBox checkBox23Airpilot;
        private System.Windows.Forms.CheckBox checkBox22House;
        private System.Windows.Forms.CheckBox checkBox21Lock;
        private System.Windows.Forms.CheckBox checkBox20HeatAir;
        private System.Windows.Forms.CheckBox checkBox19Plum;
        private System.Windows.Forms.CheckBox checkBox18Carpenter;
        private System.Windows.Forms.CheckBox checkBox17Solo;
        private System.Windows.Forms.CheckBox checkBox16Pianio;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.CheckBox checkBox15English;
        private System.Windows.Forms.CheckBox checkBox14German;
        private System.Windows.Forms.CheckBox checkBox13Spanish;
        private System.Windows.Forms.CheckBox checkBox11Math;
        private System.Windows.Forms.CheckBox checkBox10Elect;
        private System.Windows.Forms.CheckBox checkBox9lawn;
        private System.Windows.Forms.CheckBox checkBox8foodsvc;
        private System.Windows.Forms.CheckBox checkBox7driver;
        private System.Windows.Forms.CheckBox checkBox6nurse;
        private System.Windows.Forms.CheckBox checkBox5care;
        private System.Windows.Forms.CheckBox checkBox4PublSpeak;
        private System.Windows.Forms.CheckBox checkBox3AutoMech;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.CheckBox chkCooking;
        private System.Windows.Forms.CheckBox chkTreeCutting;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbtnAnd;
        private System.Windows.Forms.RadioButton rbtnOR;
    }
}


