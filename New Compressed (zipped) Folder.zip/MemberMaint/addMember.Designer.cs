﻿namespace MemberMaint
{
    partial class addMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtBdateMM = new System.Windows.Forms.TextBox();
            this.txtHousePhone = new System.Windows.Forms.TextBox();
            this.btnSaveChanges = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnAddChangeImage = new System.Windows.Forms.Button();
            this.cbxPstatus = new System.Windows.Forms.ComboBox();
            this.cbxMStatus = new System.Windows.Forms.ComboBox();
            this.cmbGroup1 = new System.Windows.Forms.ComboBox();
            this.cmbGroup2 = new System.Windows.Forms.ComboBox();
            this.cmbGroup3 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnDeleteMember = new System.Windows.Forms.Button();
            this.btnNewMember = new System.Windows.Forms.Button();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtAnniversaryDD = new System.Windows.Forms.TextBox();
            this.txtAnniversaryMM = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtMemberSinceMM = new System.Windows.Forms.TextBox();
            this.txtAnniversaryYYYY = new System.Windows.Forms.TextBox();
            this.txtMemberSinceDD = new System.Windows.Forms.TextBox();
            this.txtMemberSinceYYYY = new System.Windows.Forms.TextBox();
            this.txtBdateDD = new System.Windows.Forms.TextBox();
            this.txtBdateYYYY = new System.Windows.Forms.TextBox();
            this.txtJulian = new System.Windows.Forms.TextBox();
            this.panAgeStat = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtMembFor = new System.Windows.Forms.TextBox();
            this.txtMarriedFor = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbMilitary = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtOccuoation = new System.Windows.Forms.TextBox();
            this.btnDeltPict = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtSEX = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.labUser = new System.Windows.Forms.Label();
            this.labTime = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panAgeStat.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(236, 218);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(510, 5);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(178, 20);
            this.txtLastName.TabIndex = 1;
            this.txtLastName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtLastName_MouseClick);
            this.txtLastName.TextChanged += new System.EventHandler(this.txtLastName_TextChanged);
            // 
            // txtFullName
            // 
            this.txtFullName.BackColor = System.Drawing.SystemColors.Menu;
            this.txtFullName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFullName.Location = new System.Drawing.Point(318, 48);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(178, 13);
            this.txtFullName.TabIndex = 1;
            this.txtFullName.TabStop = false;
            this.txtFullName.Leave += new System.EventHandler(this.txtFullName_Leave);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(350, 142);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(178, 20);
            this.txtEmail.TabIndex = 3;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(293, 263);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(178, 20);
            this.txtPhone.TabIndex = 13;
            // 
            // txtBdateMM
            // 
            this.txtBdateMM.Location = new System.Drawing.Point(415, 168);
            this.txtBdateMM.Name = "txtBdateMM";
            this.txtBdateMM.Size = new System.Drawing.Size(23, 20);
            this.txtBdateMM.TabIndex = 4;
            this.txtBdateMM.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtHousePhone
            // 
            this.txtHousePhone.Location = new System.Drawing.Point(293, 289);
            this.txtHousePhone.Name = "txtHousePhone";
            this.txtHousePhone.Size = new System.Drawing.Size(178, 20);
            this.txtHousePhone.TabIndex = 14;
            // 
            // btnSaveChanges
            // 
            this.btnSaveChanges.Location = new System.Drawing.Point(609, 337);
            this.btnSaveChanges.Name = "btnSaveChanges";
            this.btnSaveChanges.Size = new System.Drawing.Size(132, 23);
            this.btnSaveChanges.TabIndex = 24;
            this.btnSaveChanges.Text = "Save Changes";
            this.btnSaveChanges.UseVisualStyleBackColor = true;
            this.btnSaveChanges.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(452, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 97;
            this.label1.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Location = new System.Drawing.Point(261, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 99;
            this.label2.Text = "Full Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(270, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "E-mail";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(205, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Personal Phone";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(551, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Membership Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(551, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Personal Status";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(264, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "Birth Date  MMDDYYYY";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(205, 289);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "Home Phone";
            // 
            // btnAddChangeImage
            // 
            this.btnAddChangeImage.Location = new System.Drawing.Point(108, 236);
            this.btnAddChangeImage.Name = "btnAddChangeImage";
            this.btnAddChangeImage.Size = new System.Drawing.Size(132, 23);
            this.btnAddChangeImage.TabIndex = 26;
            this.btnAddChangeImage.Text = "Add/Change Picture ";
            this.btnAddChangeImage.UseVisualStyleBackColor = true;
            this.btnAddChangeImage.Click += new System.EventHandler(this.btnAddChangeImage_Click);
            // 
            // cbxPstatus
            // 
            this.cbxPstatus.FormattingEnabled = true;
            this.cbxPstatus.Location = new System.Drawing.Point(654, 191);
            this.cbxPstatus.Name = "cbxPstatus";
            this.cbxPstatus.Size = new System.Drawing.Size(121, 21);
            this.cbxPstatus.TabIndex = 20;
            // 
            // cbxMStatus
            // 
            this.cbxMStatus.FormattingEnabled = true;
            this.cbxMStatus.Location = new System.Drawing.Point(654, 162);
            this.cbxMStatus.Name = "cbxMStatus";
            this.cbxMStatus.Size = new System.Drawing.Size(121, 21);
            this.cbxMStatus.TabIndex = 19;
            // 
            // cmbGroup1
            // 
            this.cmbGroup1.FormattingEnabled = true;
            this.cmbGroup1.Location = new System.Drawing.Point(654, 31);
            this.cmbGroup1.Name = "cmbGroup1";
            this.cmbGroup1.Size = new System.Drawing.Size(121, 21);
            this.cmbGroup1.TabIndex = 15;
            // 
            // cmbGroup2
            // 
            this.cmbGroup2.FormattingEnabled = true;
            this.cmbGroup2.Location = new System.Drawing.Point(654, 58);
            this.cmbGroup2.Name = "cmbGroup2";
            this.cmbGroup2.Size = new System.Drawing.Size(121, 21);
            this.cmbGroup2.TabIndex = 16;
            // 
            // cmbGroup3
            // 
            this.cmbGroup3.FormattingEnabled = true;
            this.cmbGroup3.Location = new System.Drawing.Point(654, 85);
            this.cmbGroup3.Name = "cmbGroup3";
            this.cmbGroup3.Size = new System.Drawing.Size(121, 21);
            this.cmbGroup3.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(591, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "3rd Group";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(591, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "2nd Group";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(594, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "1st group";
            // 
            // btnDeleteMember
            // 
            this.btnDeleteMember.Location = new System.Drawing.Point(609, 362);
            this.btnDeleteMember.Name = "btnDeleteMember";
            this.btnDeleteMember.Size = new System.Drawing.Size(175, 23);
            this.btnDeleteMember.TabIndex = 25;
            this.btnDeleteMember.Text = "Delete This Member";
            this.btnDeleteMember.UseVisualStyleBackColor = true;
            this.btnDeleteMember.Click += new System.EventHandler(this.btnDeleteMember_Click);
            // 
            // btnNewMember
            // 
            this.btnNewMember.Location = new System.Drawing.Point(609, 384);
            this.btnNewMember.Name = "btnNewMember";
            this.btnNewMember.Size = new System.Drawing.Size(175, 23);
            this.btnNewMember.TabIndex = 26;
            this.btnNewMember.Text = "Make New Member Record";
            this.btnNewMember.UseVisualStyleBackColor = true;
            this.btnNewMember.Click += new System.EventHandler(this.btnNewMember_Click);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(350, 88);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAddress.Size = new System.Drawing.Size(178, 50);
            this.txtAddress.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(264, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 43;
            this.label13.Text = "Anniversary Date ";
            // 
            // txtAnniversaryDD
            // 
            this.txtAnniversaryDD.Location = new System.Drawing.Point(444, 194);
            this.txtAnniversaryDD.Name = "txtAnniversaryDD";
            this.txtAnniversaryDD.Size = new System.Drawing.Size(24, 20);
            this.txtAnniversaryDD.TabIndex = 8;
            this.txtAnniversaryDD.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtAnniversaryMM
            // 
            this.txtAnniversaryMM.Location = new System.Drawing.Point(415, 194);
            this.txtAnniversaryMM.Name = "txtAnniversaryMM";
            this.txtAnniversaryMM.Size = new System.Drawing.Size(23, 20);
            this.txtAnniversaryMM.TabIndex = 7;
            this.txtAnniversaryMM.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(264, 223);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 13);
            this.label14.TabIndex = 46;
            this.label14.Text = "Member Since Date";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(39, 413);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(175, 23);
            this.btnExit.TabIndex = 27;
            this.btnExit.Text = "exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtMemberSinceMM
            // 
            this.txtMemberSinceMM.Location = new System.Drawing.Point(414, 220);
            this.txtMemberSinceMM.Name = "txtMemberSinceMM";
            this.txtMemberSinceMM.Size = new System.Drawing.Size(24, 20);
            this.txtMemberSinceMM.TabIndex = 10;
            this.txtMemberSinceMM.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtAnniversaryYYYY
            // 
            this.txtAnniversaryYYYY.Location = new System.Drawing.Point(474, 194);
            this.txtAnniversaryYYYY.Name = "txtAnniversaryYYYY";
            this.txtAnniversaryYYYY.Size = new System.Drawing.Size(39, 20);
            this.txtAnniversaryYYYY.TabIndex = 9;
            this.txtAnniversaryYYYY.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtMemberSinceDD
            // 
            this.txtMemberSinceDD.Location = new System.Drawing.Point(444, 220);
            this.txtMemberSinceDD.Name = "txtMemberSinceDD";
            this.txtMemberSinceDD.Size = new System.Drawing.Size(24, 20);
            this.txtMemberSinceDD.TabIndex = 11;
            this.txtMemberSinceDD.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtMemberSinceYYYY
            // 
            this.txtMemberSinceYYYY.Location = new System.Drawing.Point(474, 220);
            this.txtMemberSinceYYYY.Name = "txtMemberSinceYYYY";
            this.txtMemberSinceYYYY.Size = new System.Drawing.Size(39, 20);
            this.txtMemberSinceYYYY.TabIndex = 12;
            this.txtMemberSinceYYYY.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtBdateDD
            // 
            this.txtBdateDD.Location = new System.Drawing.Point(444, 168);
            this.txtBdateDD.Name = "txtBdateDD";
            this.txtBdateDD.Size = new System.Drawing.Size(23, 20);
            this.txtBdateDD.TabIndex = 5;
            this.txtBdateDD.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtBdateYYYY
            // 
            this.txtBdateYYYY.Location = new System.Drawing.Point(474, 168);
            this.txtBdateYYYY.Name = "txtBdateYYYY";
            this.txtBdateYYYY.Size = new System.Drawing.Size(39, 20);
            this.txtBdateYYYY.TabIndex = 6;
            this.txtBdateYYYY.TextChanged += new System.EventHandler(this.txtBdateYYYY_TextChanged);
            // 
            // txtJulian
            // 
            this.txtJulian.Location = new System.Drawing.Point(708, 415);
            this.txtJulian.Name = "txtJulian";
            this.txtJulian.Size = new System.Drawing.Size(67, 20);
            this.txtJulian.TabIndex = 47;
            // 
            // panAgeStat
            // 
            this.panAgeStat.Controls.Add(this.label24);
            this.panAgeStat.Controls.Add(this.label23);
            this.panAgeStat.Controls.Add(this.label22);
            this.panAgeStat.Controls.Add(this.txtMembFor);
            this.panAgeStat.Controls.Add(this.txtMarriedFor);
            this.panAgeStat.Controls.Add(this.txtAge);
            this.panAgeStat.Controls.Add(this.label21);
            this.panAgeStat.Location = new System.Drawing.Point(12, 266);
            this.panAgeStat.Name = "panAgeStat";
            this.panAgeStat.Size = new System.Drawing.Size(133, 100);
            this.panAgeStat.TabIndex = 48;
            this.panAgeStat.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 73);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(64, 13);
            this.label24.TabIndex = 6;
            this.label24.Text = "Membership";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 50);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 13);
            this.label23.TabIndex = 5;
            this.label23.Text = "Marrage";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "Age";
            // 
            // txtMembFor
            // 
            this.txtMembFor.Location = new System.Drawing.Point(90, 70);
            this.txtMembFor.Name = "txtMembFor";
            this.txtMembFor.Size = new System.Drawing.Size(36, 20);
            this.txtMembFor.TabIndex = 3;
            // 
            // txtMarriedFor
            // 
            this.txtMarriedFor.Location = new System.Drawing.Point(90, 45);
            this.txtMarriedFor.Name = "txtMarriedFor";
            this.txtMarriedFor.Size = new System.Drawing.Size(36, 20);
            this.txtMarriedFor.TabIndex = 2;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(90, 21);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(36, 20);
            this.txtAge.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 4);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "for Years of:";
            // 
            // cmbMilitary
            // 
            this.cmbMilitary.FormattingEnabled = true;
            this.cmbMilitary.Items.AddRange(new object[] {
            "National Guard",
            "Army",
            "Navy",
            "Air force",
            "Marines",
            "Coast Guard",
            "Reserves",
            "none"});
            this.cmbMilitary.Location = new System.Drawing.Point(654, 118);
            this.cmbMilitary.Name = "cmbMilitary";
            this.cmbMilitary.Size = new System.Drawing.Size(121, 21);
            this.cmbMilitary.TabIndex = 18;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(606, 121);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 13);
            this.label25.TabIndex = 50;
            this.label25.Text = "Military";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(5, 27);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(65, 17);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Cooking";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(5, 47);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(84, 17);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Tree Cutting";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBox29);
            this.panel1.Controls.Add(this.checkBox28);
            this.panel1.Controls.Add(this.checkBox27);
            this.panel1.Controls.Add(this.checkBox26);
            this.panel1.Controls.Add(this.checkBox25);
            this.panel1.Controls.Add(this.checkBox24);
            this.panel1.Controls.Add(this.checkBox23);
            this.panel1.Controls.Add(this.checkBox22);
            this.panel1.Controls.Add(this.checkBox21);
            this.panel1.Controls.Add(this.checkBox20);
            this.panel1.Controls.Add(this.checkBox19);
            this.panel1.Controls.Add(this.checkBox18);
            this.panel1.Controls.Add(this.checkBox17);
            this.panel1.Controls.Add(this.checkBox16);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.checkBox15);
            this.panel1.Controls.Add(this.checkBox14);
            this.panel1.Controls.Add(this.checkBox11);
            this.panel1.Controls.Add(this.checkBox10);
            this.panel1.Controls.Add(this.checkBox9);
            this.panel1.Controls.Add(this.checkBox8);
            this.panel1.Controls.Add(this.checkBox7);
            this.panel1.Controls.Add(this.checkBox6);
            this.panel1.Controls.Add(this.checkBox5);
            this.panel1.Controls.Add(this.checkBox4);
            this.panel1.Controls.Add(this.checkBox3);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.checkBox2);
            this.panel1.Controls.Add(this.checkBox13);
            this.panel1.Location = new System.Drawing.Point(806, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(307, 356);
            this.panel1.TabIndex = 22;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Location = new System.Drawing.Point(138, 287);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(97, 17);
            this.checkBox29.TabIndex = 28;
            this.checkBox29.Text = "Computer Nerd";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(138, 267);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(85, 17);
            this.checkBox28.TabIndex = 27;
            this.checkBox28.Text = "Audio/Video";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Location = new System.Drawing.Point(138, 247);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(100, 17);
            this.checkBox27.TabIndex = 26;
            this.checkBox27.Text = "Youth Ministries";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(138, 227);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(97, 17);
            this.checkBox26.TabIndex = 25;
            this.checkBox26.Text = "Teen Ministries";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(138, 207);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(65, 17);
            this.checkBox25.TabIndex = 24;
            this.checkBox25.Text = "Organist";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(138, 187);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(93, 17);
            this.checkBox24.TabIndex = 23;
            this.checkBox24.Text = "Aircraft Owner";
            this.checkBox24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(138, 167);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(82, 17);
            this.checkBox23.TabIndex = 22;
            this.checkBox23.Text = "Aircraft Pilot";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(138, 147);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(101, 17);
            this.checkBox22.TabIndex = 21;
            this.checkBox22.Text = "House Cleaning";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(138, 127);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(88, 17);
            this.checkBox21.TabIndex = 20;
            this.checkBox21.Text = "Locksmithing";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(138, 107);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(72, 17);
            this.checkBox20.TabIndex = 19;
            this.checkBox20.Text = "Heat / Air";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(138, 87);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(69, 17);
            this.checkBox19.TabIndex = 18;
            this.checkBox19.Text = "Plumbing";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(138, 67);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(72, 17);
            this.checkBox18.TabIndex = 17;
            this.checkBox18.Text = "Carpenter";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(138, 47);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(57, 17);
            this.checkBox17.TabIndex = 16;
            this.checkBox17.Text = "Soloist";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(138, 27);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(57, 17);
            this.checkBox16.TabIndex = 15;
            this.checkBox16.Text = "Pianist";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(43, 328);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(212, 17);
            this.label28.TabIndex = 68;
            this.label28.Text = "Please Check All That Apply";
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(5, 287);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(102, 17);
            this.checkBox15.TabIndex = 14;
            this.checkBox15.Text = "English Tutoring";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(5, 267);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(118, 17);
            this.checkBox14.TabIndex = 13;
            this.checkBox14.Text = "German Translation";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(5, 227);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(92, 17);
            this.checkBox11.TabIndex = 11;
            this.checkBox11.Text = "Math Tutoring";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(5, 207);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(102, 17);
            this.checkBox10.TabIndex = 10;
            this.checkBox10.Text = "Electrical Wiring";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(5, 187);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(77, 17);
            this.checkBox9.TabIndex = 9;
            this.checkBox9.Text = "Lawn Care";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(5, 167);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(89, 17);
            this.checkBox8.TabIndex = 8;
            this.checkBox8.Text = "Food Service";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(5, 147);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(54, 17);
            this.checkBox7.TabIndex = 7;
            this.checkBox7.Text = "Driver";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(5, 127);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(65, 17);
            this.checkBox6.TabIndex = 6;
            this.checkBox6.Text = "Nursing ";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(5, 107);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(103, 17);
            this.checkBox5.TabIndex = 5;
            this.checkBox5.Text = "Child/Adult Care";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(5, 87);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(103, 17);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.Text = "Public Speaking";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(5, 67);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(98, 17);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Auto Mechanic";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(43, 5);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(112, 15);
            this.label27.TabIndex = 54;
            this.label27.Text = "Shareable Skills";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(5, 247);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(119, 17);
            this.checkBox13.TabIndex = 12;
            this.checkBox13.Text = "Spanish Translation";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(523, 223);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(62, 13);
            this.label29.TabIndex = 56;
            this.label29.Text = "Occupation";
            // 
            // txtOccuoation
            // 
            this.txtOccuoation.Location = new System.Drawing.Point(597, 223);
            this.txtOccuoation.Name = "txtOccuoation";
            this.txtOccuoation.Size = new System.Drawing.Size(178, 20);
            this.txtOccuoation.TabIndex = 21;
            // 
            // btnDeltPict
            // 
            this.btnDeltPict.Location = new System.Drawing.Point(18, 236);
            this.btnDeltPict.Name = "btnDeltPict";
            this.btnDeltPict.Size = new System.Drawing.Size(84, 23);
            this.btnDeltPict.TabIndex = 58;
            this.btnDeltPict.Text = "Delete Picture";
            this.btnDeltPict.UseVisualStyleBackColor = true;
            this.btnDeltPict.Click += new System.EventHandler(this.btnDeltPict_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(173, 362);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(132, 23);
            this.button3.TabIndex = 59;
            this.button3.Text = "clear data fields";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtSEX
            // 
            this.txtSEX.Location = new System.Drawing.Point(250, 311);
            this.txtSEX.Name = "txtSEX";
            this.txtSEX.Size = new System.Drawing.Size(24, 20);
            this.txtSEX.TabIndex = 60;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(205, 313);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(42, 13);
            this.label30.TabIndex = 61;
            this.label30.Text = "Gender";
            // 
            // labUser
            // 
            this.labUser.AutoSize = true;
            this.labUser.Location = new System.Drawing.Point(886, 418);
            this.labUser.Name = "labUser";
            this.labUser.Size = new System.Drawing.Size(27, 13);
            this.labUser.TabIndex = 62;
            this.labUser.Text = "user";
            // 
            // labTime
            // 
            this.labTime.AutoSize = true;
            this.labTime.Location = new System.Drawing.Point(990, 418);
            this.labTime.Name = "labTime";
            this.labTime.Size = new System.Drawing.Size(26, 13);
            this.labTime.TabIndex = 63;
            this.labTime.Text = "time";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(815, 418);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 13);
            this.label17.TabIndex = 64;
            this.label17.Text = "Last update ";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(318, 5);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(128, 20);
            this.txtFirstName.TabIndex = 0;
            this.txtFirstName.MouseLeave += new System.EventHandler(this.txtFirstName_MouseLeave);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(255, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 98;
            this.label15.Text = "First Name";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(609, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 37);
            this.button1.TabIndex = 23;
            this.button1.Text = "Exit Quit SQLmemberMaint";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // addMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.labTime);
            this.Controls.Add(this.labUser);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.txtSEX);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnDeltPict);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtOccuoation);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.cmbMilitary);
            this.Controls.Add(this.panAgeStat);
            this.Controls.Add(this.txtJulian);
            this.Controls.Add(this.txtBdateYYYY);
            this.Controls.Add(this.txtBdateDD);
            this.Controls.Add(this.txtMemberSinceYYYY);
            this.Controls.Add(this.txtMemberSinceDD);
            this.Controls.Add(this.txtAnniversaryYYYY);
            this.Controls.Add(this.txtMemberSinceMM);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtAnniversaryMM);
            this.Controls.Add(this.txtAnniversaryDD);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.btnNewMember);
            this.Controls.Add(this.btnDeleteMember);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbGroup3);
            this.Controls.Add(this.cmbGroup2);
            this.Controls.Add(this.cmbGroup1);
            this.Controls.Add(this.cbxMStatus);
            this.Controls.Add(this.cbxPstatus);
            this.Controls.Add(this.btnAddChangeImage);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSaveChanges);
            this.Controls.Add(this.txtHousePhone);
            this.Controls.Add(this.txtBdateMM);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.pictureBox1);
            this.Name = "addMember";
            this.Text = "addMember";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panAgeStat.ResumeLayout(false);
            this.panAgeStat.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtBdateMM;
        private System.Windows.Forms.TextBox txtHousePhone;
        private System.Windows.Forms.Button btnSaveChanges;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnAddChangeImage;
        private System.Windows.Forms.ComboBox cbxPstatus;
        private System.Windows.Forms.ComboBox cbxMStatus;
        private System.Windows.Forms.ComboBox cmbGroup1;
        private System.Windows.Forms.ComboBox cmbGroup2;
        private System.Windows.Forms.ComboBox cmbGroup3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnDeleteMember;
        private System.Windows.Forms.Button btnNewMember;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtAnniversaryDD;
        private System.Windows.Forms.TextBox txtAnniversaryMM;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtMemberSinceMM;
        private System.Windows.Forms.TextBox txtAnniversaryYYYY;
        private System.Windows.Forms.TextBox txtMemberSinceDD;
        private System.Windows.Forms.TextBox txtMemberSinceYYYY;
        private System.Windows.Forms.TextBox txtBdateDD;
        private System.Windows.Forms.TextBox txtBdateYYYY;
        private System.Windows.Forms.TextBox txtJulian;
        private System.Windows.Forms.Panel panAgeStat;
        private System.Windows.Forms.TextBox txtMembFor;
        private System.Windows.Forms.TextBox txtMarriedFor;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbMilitary;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtOccuoation;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.Button btnDeltPict;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtSEX;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.Label labUser;
        private System.Windows.Forms.Label labTime;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
    }
}